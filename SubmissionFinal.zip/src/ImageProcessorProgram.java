import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;

import controller.ControllerImpl;
import controller.IController;
import model.ImageProcessorModel;
import view.IView;
import view.ImageProcessorView;

/**
 * Represents the program that runs the controller.
 */
public class ImageProcessorProgram {
  /**
   * Represents the main input method.
   *
   * @param args the string arguments
   */
  public static void main(String[] args) throws IOException {
    Readable rd;
    Appendable ap = new StringBuilder();

    if (args.length > 0) {

      String input = "";
      BufferedReader br;

      br = new BufferedReader(new FileReader(args[0]));

      String contentLine = br.readLine();
      input = input + contentLine + "\n";
      while (contentLine != null) {

        System.out.println(contentLine);

        contentLine = br.readLine();
        input = input + contentLine + "\n";
        ap.append(input);
      }

      rd = new StringReader(input);


    } else {
      rd = new InputStreamReader(System.in);
    }

    Appendable appendable = System.out;
    ImageProcessorModel processorModel = new ImageProcessorModel();
    IView view = new ImageProcessorView(appendable);


    IController controller = new ControllerImpl(processorModel, view, rd);
    controller.runProcessor();
  }
}
