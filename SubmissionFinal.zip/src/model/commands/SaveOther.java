package model.commands;

import model.ImageProcessorModel;

/**
 * Represents the save other command class that is used to save other image types.
 */
public class SaveOther extends AbstractCommands {

  /**
   * Constructor for the given command, used to run command.
   *
   * @param fileName the name of the file
   * @param rename   the new name of the image
   */
  public SaveOther(String fileName, String rename) {
    super(fileName, rename);
  }

  @Override
  public void start(ImageProcessorModel m) {
    m.saveOtherImages(this.fileName, this.rename);
  }
}

