package model.commands;

import model.ImageProcessorModel;

/**
 * Represents the load other command class that is used to load other image types.
 */
public class LoadOther extends AbstractCommands {

  /**
   * Constructor for the given command, used to run command.
   *
   * @param fileName the name of the file
   * @param rename   the image
   */
  public LoadOther(String fileName, String rename) {
    super(fileName, rename);
  }

  @Override
  public void start(ImageProcessorModel m) {
    m.loadOtherTypes(this.fileName, this.rename);
  }
}

